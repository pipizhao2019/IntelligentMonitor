const app = getApp()

Page({
  data:{
    userInfo: ''
  },
  onLoad(){
    
    let user = wx.getStorageSync('userStorage')
    console.log('进入小程序index页面' , user)
    this.setData({
      userInfo: user
    })
  },
 

  // login(){
  //   let that = this
  //   console.log('点击事件执行')
  //   wx.getUserProfile({
  //     desc: '用于完善用户资料', // 声明获取用户个人信息后的用途，后续会展示在弹窗中，请谨慎填写
  //     success(res){
  //       console.log('授权成功',res.userInfo)
  //       that.setData({
  //         nickName: res.userInfo.nickName
  //       })
  //     },
  //     fail(res){
  //       console.log('授权失败',res)
  //     }
  //   })
  // },

  //授权登录 ES6语法避免this指代
  login(){
    // console.log('点击事件执行')
    wx.getUserProfile({
      desc: '用于完善用户资料', // 声明获取用户个人信息后的用途，后续会展示在弹窗中，请谨慎填写
      success:res => {
        let user = res.userInfo
        this.SaveUserInfo(res.userInfo)
        //用户信息缓存本地
        wx.setStorageSync('userStorage', user)
        console.log('授权成功',user)
        this.setData({
          userInfo: user,
          
        })
      },
      fail:res => {
        console.log('授权失败',res)
      }
    })
  },
  //退出登录
  quit(){
    this.setData({
      userInfo: ''
    })
    wx.setStorageSync('userStorage', null)
  },

  SaveUserInfo(userInfo){
    app.globalData.userInfo = userInfo
  },

  GetMassage(){
    wx.navigateTo({
      url: 'CarIDPhoneNumber/CarIDPhoneNumber',
      
    })
  },
  Upload(){
    wx.navigateTo({
      url: 'discern/discern',
      
    })
  },

})