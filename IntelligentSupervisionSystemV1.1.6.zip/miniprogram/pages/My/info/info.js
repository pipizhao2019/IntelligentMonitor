// pages/My/info/info.js
const app = getApp()

Page({

  /**
   * 页面的初始数据
   */
  data: {
    nickName: app.globalData.nickName,
    avatarUrl: app.globalData.avatarUrl,
    gender: app.globalData.gender,
    province: app.globalData.province,
    city: app.globalData.city,
    countr: app.globalData.countr,
  },
 








  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    //此时需要判断全局数据是否获取到
  
  //如果已经获取到，则直接使用
  if(app.appData.userInfo){
    //如果此处的逻辑较多可以提炼为一个函数
    this.setData({
      userInfo:app.appData.userInfo
    })
  }else{
  //如果还未请求到数据，则创建一个回调函数，等待数据获取完成后调用
    app.userInfoCallback = res => {
      this.setData({
        userInfo:app.appData.userInfo
      })
    }
  }

},
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})