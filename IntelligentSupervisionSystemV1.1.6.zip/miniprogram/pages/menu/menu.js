const app = getApp()
var day = ["今天","明天","后天"];
Page({
  data: {
    hideNotice: false,
    qlty:[],
    location:'',
    day: day,
    city: '',
    district:'',
    street:'',
    tem:"",
    txt:'',
    windDir:'',
    userInfo: {},
    hasUserInfo: false,
    canIUse: wx.canIUse('button.open-type.getUserInfo'),
    canIUseGetUserProfile: false,
    canIUseOpenData: wx.canIUse('open-data.type.userAvatarUrl') && wx.canIUse('open-data.type.userNickName'), // 如需尝试获取用户信息可改为false
    cardCur: 0,
    swiperList: [{
      id: 0,
      type: 'image',
      url: 'https://s1.ax1x.com/2022/03/06/bDBqBD.png'
    }, {
      id: 1,
        type: 'image',
        url: 'https://s1.ax1x.com/2022/03/06/bDBbnO.png',
    }, {
      id: 2,
      type: 'image',
      url: 'https://s1.ax1x.com/2022/03/06/bDBLHe.png'
    }, {
      id: 3,
      type: 'image',
      url: 'https://s1.ax1x.com/2022/03/06/bDBjNd.png'
    }],
  
  },

 
  onLoad:function() {
    if (wx.getUserProfile) {
      var that = this
      that.getLocation();
    }
    this.towerSwiper('swiperList');
    // 初始化towerSwiper 传已有的数组名即可
  },

  DotStyle(e) {
    this.setData({
      DotStyle: e.detail.value
    })
  },
  //获取经纬度方法
  getLocation: function () {
    var that = this
    wx.getLocation({
      type: 'wgs84',
      success: function (res) {
        var latitude = res.latitude
        var longitude = res.longitude
        that.getCity(latitude, longitude);
      }
    })
  },

  getCity: function (latitude, longitude) {
    var that = this
    var url = "https://api.map.baidu.com/reverse_geocoding/v3/";
    var params = {
      ak: "th2ePM17xOgguMNNQp5YqvQ1WHwq74ko",
      output: "json",
      location: latitude + "," + longitude
    }
    wx.request({
      url: url,
      data: params,
      
      success: function (res) {
        console.log(res.data.result.location.lng)
        var city = res.data.result.addressComponent.city;
        var district = res.data.result.addressComponent.district;
        var street = res.data.result.addressComponent.street;
        var location = res.data.result.location.lng+','+res.data.result.location.lat;
        that.setData({
          city: city,
          district: district,
          street: street,
          location: location,
         
        })
        console.log(city)
        var descCity = city.substring(0, city.length - 1);
        that.getWeahter(descCity,location);
      },
      fail: function (res) { },
      complete: function (res) { },
    })
  },

  //获取常规天气信息
  getWeahter: function (city,locations) {
    console.log(locations)
    var that = this
    var url = "https://devapi.qweather.com/v7/weather/now"
    var params = {
      location: locations,
      key: "b8aad690b6cd4563ad716db0f9654f95"    }
    wx.request({
      url: url,
      data: params,
      method: 'GET',
      header:{  "content-type": "application/json"},
      success: function (res) {
          console.log(res)
          
            var tmp = res.data.now.temp;
            var txt = res.data.now.text;
            var windDir = res.data.now.windDir;
            var windScale = res.data.now.windScale;
            /*var code = res.data.HeWeather6[0].now.cond_code;
            var vis = res.data.HeWeather6[0].now.vis;
            var dir = res.data.HeWeather6[0].now.wind_dir;
            var sc = res.data.HeWeather6[0].now.wind_sc;
            var fl = res.data.HeWeather6[0].now.fl;
            var notice = res.data.HeWeather6[0].lifestyle[2].txt;
            var daily_forecast = res.data.HeWeather6[0].daily_forecast;*/
          
        
        that.setData({
          tmp: tmp,
          txt: txt,
          windDir: windDir,
          windScale: windScale,
          /*code: code,
          vis: vis,
          dir: dir,
          sc: sc,
          hum: hum,
          fl: fl,
          daily_forecast: daily_forecast,
          notice: notice*/
        })
       that.getWeahterWarning(city,locations);
      },
      fail: function (res) { },
      complete: function (res) { },
    })
  },


  //获取空气质量
  getWeahterWarning: function (city,locations) {
    var that = this
    var url = "https://devapi.qweather.com/v7/warning/now"
    var params = {
      key: "b8aad690b6cd4563ad716db0f9654f95",
      location: locations,
         }
    wx.request({
      url: url,
      data: params,
      success: function (res) {
        console.log(res)
        var qlty = res.data.warning;
        that.setData({
          qlty: qlty,
        })
      },
      fail: function (res) { },
      complete: function (res) { },
    })
  },

  
  getUserProfile(e) {
    // 推荐使用wx.getUserProfile获取用户信息，开发者每次通过该接口获取用户个人信息均需用户确认，开发者妥善保管用户快速填写的头像昵称，避免重复弹窗
    wx.getUserProfile({
      desc: '展示用户信息', // 声明获取用户个人信息后的用途，后续会展示在弹窗中，请谨慎填写
      success: (res) => {
        console.log(res)
        this.setData({
          userInfo: res.userInfo,
          hasUserInfo: true
        })
      }
    })
  },
 // cardSwiper
 cardSwiper(e) {
  this.setData({
    cardCur: e.detail.current
  })
},
// towerSwiper
// 初始化towerSwiper
towerSwiper(name) {
  let list = this.data[name];
  for (let i = 0; i < list.length; i++) {
    list[i].zIndex = parseInt(list.length / 2) + 1 - Math.abs(i - parseInt(list.length / 2))
    list[i].mLeft = i - parseInt(list.length / 2)
  }
  this.setData({
    swiperList: list
  })
},
// towerSwiper触摸开始
towerStart(e) {
  this.setData({
    towerStart: e.touches[0].pageX
  })
},
// towerSwiper计算方向
towerMove(e) {
  this.setData({
    direction: e.touches[0].pageX - this.data.towerStart > 0 ? 'right' : 'left'
  })
},
// towerSwiper计算滚动
towerEnd(e) {
  let direction = this.data.direction;
  let list = this.data.swiperList;
  if (direction == 'right') {
    let mLeft = list[0].mLeft;
    let zIndex = list[0].zIndex;
    for (let i = 1; i < list.length; i++) {
      list[i - 1].mLeft = list[i].mLeft
      list[i - 1].zIndex = list[i].zIndex
    }
    list[list.length - 1].mLeft = mLeft;
    list[list.length - 1].zIndex = zIndex;
    this.setData({
      swiperList: list
    })
  } else {
    let mLeft = list[list.length - 1].mLeft;
    let zIndex = list[list.length - 1].zIndex;
    for (let i = list.length - 1; i > 0; i--) {
      list[i].mLeft = list[i - 1].mLeft
      list[i].zIndex = list[i - 1].zIndex
    }
    list[0].mLeft = mLeft;
    list[0].zIndex = zIndex;
    this.setData({
      swiperList: list
    })
  }
},
//下拉刷新
onPullDownRefresh: function () {
  var that = this
  that.getLocation();
  //下拉刷新后回弹
  wx.stopPullDownRefresh();
},

  getWeather(){
    wx.navigateTo({
      url: '../menu/weather/weather',
    })
  },
  getKnowledge(){
    wx.navigateTo({
      url: '../menu/Knowledge/Knowledge',
    })
  },
  FeedBack(){
    wx.navigateTo({
      url: '../menu/CustomerService/CustomerService',
    })
  }
})