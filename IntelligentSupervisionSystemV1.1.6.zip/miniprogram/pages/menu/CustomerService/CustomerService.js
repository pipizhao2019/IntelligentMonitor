const app = getApp();
Page({
  data: {
    StatusBar: app.globalData.StatusBar,
    CustomBar: app.globalData.CustomBar,
    index: null,
    picker: ['违章停车', '压线行驶', '不礼让行人'],
    multiArray: [
      ['道路礼仪', '压线行驶','道路礼仪'],
      ['超速行驶', '超速行驶', '行驶中手持电话', '超载', '闯红灯'],
      ['疲劳驾驶', '疲劳驾驶']
    ],
    objectMultiArray: [
      [{
          id: 0,
          name: '无脊柱动物'
        },
        {
          id: 1,
          name: '脊柱动物'
        }
      ],
      [{
          id: 0,
          name: '扁性动物'
        },
        {
          id: 1,
          name: '线形动物'
        },
        {
          id: 2,
          name: '环节动物'
        },
        {
          id: 3,
          name: '软体动物'
        },
        {
          id: 3,
          name: '节肢动物'
        }
      ],
      [{
          id: 0,
          name: '猪肉绦虫'
        },
        {
          id: 1,
          name: '吸血虫'
        }
      ]
    ],
    multiIndex: [0, 0, 0],
    time: '00:00',
    date: '2022-05-04',
    region: ['河北省', '张家口市', '桥西区'],
    imgList: [],
    modalName: null,
    textareaAValue: '',
    textareaBValue: ''
  },
  // 外网的图片的路径数组
  UpLoadImgs: [],
  handleTabsItemChange(e) {
    // 1 获取被点击的标题索引
    const { index } = e.detail;
    // 2 修改源数组
    let { tabs } = this.data;
    tabs.forEach((v, i) => i === index ? v.isActive = true : v.isActive = false);
    // 3 赋值到data中
    this.setData({
      tabs
    })
  },
  // 点击 “+” 选择图片
  handleChooseImg() {
    // 2 调用小程序内置的选择图片api
    wx.chooseImage({
      // 同时选中的图片的数量
      count: 9,
      // 图片的格式  原图  压缩
      sizeType: ['original', 'compressed'],
      // 图片的来源  相册  照相机
      sourceType: ['album', 'camera'],
      success: (result) => {
        this.setData({
          // 图片数组 进行拼接 
          chooseImgs: [...this.data.chooseImgs, ...result.tempFilePaths]
        })
      }
    });
  },
  // 根据索引删除上传的图片
  handleRemoveImg(e){
    // 1 获取被点击的组件的索引
    const {index} = e.currentTarget.dataset;
    // 2 获取data中的图片数组
    let { chooseImgs } = this.data;
    // 3 删除元素
    chooseImgs.splice(index, 1);
    this.setData({
      chooseImgs
    })
  },
 // 文本域的输入的事件
 handleTextInput(e){
  this.setData({
    textVal:e.detail.value
  })
},

//提交按钮的点击
handleFormSubmit(){
  // 1 获取文本域的内容 图片数组
  const {textVal, chooseImgs}=this.data;
  // 2 合法性的验证
  if(!textVal.trim()){
    // 不合法
    wx.showToast({
      title:'输入不合法',
      icon:'none',
      // 防止反复点击
      mask: true
    });
    return;
  }

  // 3 准备上传图片到专门的图片服务器
  // 上传文件的api不支持多个文件同时上传 遍历数组 挨个上传
  // 显示正在等待的图片
  wx.showLoading({
    title:"正在上传中...",
    mask: true
  });

  // 判断有没有需要上传的图片数组
  if (chooseImgs.length != 0){
    chooseImgs.forEach((v,i)=>{
      wx.uploadFile({
        // 图片要上传到哪里(使用图床)
        url: 'https:',
        // 被上传的文件的路径
        filePath: v,
        // 上传的文件的名称后台来获取文件file
        name: "image",
        // 顺带的文本信息
        formData: {},
        success: (result) =>{
          console.log(result);
          let url=JSON.parse (result.data);
          this.UpLoadImgs.push(url);
          // 所有的图片都上传完毕了才触发
          if(i===chooseImgs.length-1){

            // 关闭正在等待的图片
            wx.hideLoading();
            console.log("把文本的内容和外网的图片数组提交到后台中");
            // 提交都成功了
            // 重置页面
            this.setData({
              textVal:"",
              chooseImgs:[]
            })
            // 返回上一个页面
            wx.navigateBack({
              delta: 1
            });
          }
          console.log(this.UpLoadImgs);
        },
      })

    })

  }else{
    // 关闭弹窗
    wx.hideLoading();
    console.log("只是提交了文本");
    // 返回上个页面
    wx.navigateBack({
      delta:1
    });
  }
},
// 点击下拉显示框
selectTap(){
  this.setData({
    show: !this.data.show
  });
},
// 点击下拉列表
optionTap(e){
  let Index=e.currentTarget.dataset.index;//获取点击的下拉列表的下标
  this.setData({
    index:Index,
    show:!this.data.show
  });
},


showModal(e) {
  this.setData({
    modalName: e.currentTarget.dataset.target
  })
},

hideModal(e) {
  this.setData({
    modalName: null
  })
},

//新页面函数
PickerChange(e) {
  console.log(e);
  this.setData({
    index: e.detail.value
  })
},
MultiChange(e) {
  this.setData({
    multiIndex: e.detail.value
  })
},
MultiColumnChange(e) {
  let data = {
    multiArray: this.data.multiArray,
    multiIndex: this.data.multiIndex
  };
  data.multiIndex[e.detail.column] = e.detail.value;
  switch (e.detail.column) {
    case 0:
      switch (data.multiIndex[0]) {
        case 0:
          data.multiArray[1] = ['扁性动物', '线形动物', '环节动物', '软体动物', '节肢动物'];
          data.multiArray[2] = ['猪肉绦虫', '吸血虫'];
          break;
        case 1:
          data.multiArray[1] = ['鱼', '两栖动物', '爬行动物'];
          data.multiArray[2] = ['鲫鱼', '带鱼'];
          break;
      }
      data.multiIndex[1] = 0;
      data.multiIndex[2] = 0;
      break;
    case 1:
      switch (data.multiIndex[0]) {
        case 0:
          switch (data.multiIndex[1]) {
            case 0:
              data.multiArray[2] = ['猪肉绦虫', '吸血虫'];
              break;
            case 1:
              data.multiArray[2] = ['蛔虫'];
              break;
            case 2:
              data.multiArray[2] = ['蚂蚁', '蚂蟥'];
              break;
            case 3:
              data.multiArray[2] = ['河蚌', '蜗牛', '蛞蝓'];
              break;
            case 4:
              data.multiArray[2] = ['昆虫', '甲壳动物', '蛛形动物', '多足动物'];
              break;
          }
          break;
        case 1:
          switch (data.multiIndex[1]) {
            case 0:
              data.multiArray[2] = ['鲫鱼', '带鱼'];
              break;
            case 1:
              data.multiArray[2] = ['青蛙', '娃娃鱼'];
              break;
            case 2:
              data.multiArray[2] = ['蜥蜴', '龟', '壁虎'];
              break;
          }
          break;
      }
      data.multiIndex[2] = 0;
      break;
  }
  this.setData(data);
},
TimeChange(e) {
  this.setData({
    time: e.detail.value
  })
},
DateChange(e) {
  this.setData({
    date: e.detail.value
  })
},
RegionChange: function(e) {
  this.setData({
    region: e.detail.value
  })
},
ChooseImage() {
  wx.chooseImage({
    count: 4, //默认9
    sizeType: ['original', 'compressed'], //可以指定是原图还是压缩图，默认二者都有
    sourceType: ['album'], //从相册选择
    success: (res) => {
      if (this.data.imgList.length != 0) {
        this.setData({
          imgList: this.data.imgList.concat(res.tempFilePaths)
        })
      } else {
        this.setData({
          imgList: res.tempFilePaths
        })
      }
    }
  });
},
ViewImage(e) {
  wx.previewImage({
    urls: this.data.imgList,
    current: e.currentTarget.dataset.url
  });
},
DelImg(e) {
  wx.showModal({
    title: '召唤师',
    content: '确定要删除这段回忆吗？',
    cancelText: '再看看',
    confirmText: '再见',
    success: res => {
      if (res.confirm) {
        this.data.imgList.splice(e.currentTarget.dataset.index, 1);
        this.setData({
          imgList: this.data.imgList
        })
      }
    }
  })
},
textareaAInput(e) {
  this.setData({
    textareaAValue: e.detail.value
  })
},
textareaBInput(e) {
  this.setData({
    textareaBValue: e.detail.value
  })
}





})
