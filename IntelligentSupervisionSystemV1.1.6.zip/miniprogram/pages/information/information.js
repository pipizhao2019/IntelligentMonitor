// pages/index/index.js
var app = getApp();
const db = wx.cloud.database();
const _ = db.command;

var util = require("../../utils/util.js");

var today = util.formatTime(new Date()).split(' ')[0];
var maxDay = util.formatTime(new Date((new Date()).getTime() + (1000 * 60 * 60 * 24 * 60))).split(' ')[0];

var planRoute = new Array();

Page({

  /**
   * 页面的初始数据
   */
  data: {
    date: today,
    minDay: today,
    maxDay: maxDay,
    tabs: ["全部", "我的举报", "我的违章","我的申诉"],
    activeIndex: 0,
    sliderOffset: 0,
    allList: [],
    carForPerson: [],
    personForCar: [],
    date: today,
    depLatitude: '',
    depLongitude: '',
    desLatitude: '',
    desLongitude: '',
    nomore: false,
    information: {},
    infor:[],
    completed: true,  // 弹窗控制
    deposit: ''  // 存储用户输入的内容
  },

  tabClick: function(e) {
    this.setData({
      sliderOffset: e.currentTarget.offsetLeft,
      activeIndex: e.currentTarget.id
    });
  },

  bindDateChange: function(e) {
    this.setData({
      date: e.detail.value
    })
    this.getList(e.detail.value, this.data.start, this.data.over);
  },

  getStart: function(e) {
    this.setData({
      start: e.detail.value
    })
    this.getList(this.data.date, e.detail.value, this.data.over);
  },

  getOver: function(e) {
    this.setData({
      over: e.detail.value
    })
    this.getList(this.data.date, this.data.start, e.detail.value);
  },

  getList: function() {
    var that = this;

    db.collection('carpoolInfo').get({
      success: function(res) {
        var allList = res.data;
        var carForPerson = new Array();
        var personForCar = new Array();

        allList.forEach(function(item) {
          if (item.type == 1) {
            carForPerson.push(item);
          } else {
            personForCar.push(item);
          }
        })

        that.setData({
          allList: allList,
          carForPerson: carForPerson,
          personForCar: personForCar,
          nomore: true
        });
      }
    });
  },

  plan: function(e) {
    var data = e.detail.value;
    var that = this;

    if (that.data.departure == null) {
      util.showMsg('请选择违章地');
      return false;
    }

    if (that.data.destination == null) {
      util.showMsg('请选择所在地');
      return false;
    }

    db.collection('carpoolInfo').where(
      _.and({
        depLatitude: _.gte(that.data.depLatitude - 0.05).and(_.lte(that.data.depLatitude + 0.05))
      }, {
        depLongitude: _.gte(that.data.depLongitude - 0.05).and(_.lte(that.data.depLongitude + 0.05))
      }, {
        desLatitude: _.gte(that.data.desLatitude - 0.05).and(_.lte(that.data.desLatitude + 0.05))
      }, {
        desLongitude: _.gte(that.data.desLongitude - 0.05).and(_.lte(that.data.desLongitude + 0.05))
      }, {
        date: that.data.date
      })
    ).get({
      success: function(res) {
        console.log(res.data)
        that.setData({
          planRoute: res.data,
          nomore: true
        });
      },
      fail: function(res) {
        console.log('Wrong!')
      }
    });
  },

  bindDateChange: function(e) {
    this.setData({
      date: e.detail.value
    })
  },

  selectDeparture: function() {
    var that = this;
    that.setData({
      completed: false,
    })
  },

  plan1: function(){
    var that = this;
    console.log(app.globalData.chepaihao)
    
    wx.request({
      
      url: 'https://www.cj9309.cn/getInformation/login',
      // /getInfomation/login
      data: '',
      method: 'GET',
      success: (result) => {
      
        //var chepai = result.data.data[0].voi_chepai;
        //console.log(chepai)
        that.setData({
          information: result.data.data
          
        })
        

        for (var index in this.data.information) {
          //res.data.infos[index].info_file = res.data.infos[index].info_file.split(',');
          //console.log(this.data.information[index])
         
          if(this.data.information[index].voi_chepai == app.globalData.chepaihao){
            var info = this.data.information[index]
            let infor = this.data.infor
            that.setData({
              infor: infor.concat(info)
            })
            
        }

      }
       console.log(this.data.infor)
       console.log(result)
       console.log(this.data.information)
      },
      fail: (res) => {},
      complete: (res) => {},
    })
    
  },

  selectDestination: function() {
    var that = this;
    wx.chooseLocation({
      success: function(res) {
        that.setData({
          destination: res.address,
          desLatitude: res.latitude,
          desLongitude: res.longitude
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
      console.log(app.globalData.chepaihao)
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    this.getList();
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {},

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {
    return {
      title: '违章智能检测小程序',
      path: 'pages/information/information'
    }
  },
    // 获取用户输入的内容
    getUserInput(event) {
      //money = event.detail.value || event.detail.text
      this.setData({deposit: event.detail.value})
      console.log(this.data.deposit)
    },
  
    // 取消按钮触发事件
    cancelSelected(event) {
      this.setData({completed: true})
    },
  
    // 确定按钮触发事件
    successSelected(event) {
      
        this.setData({completed: true})
      
    }
})